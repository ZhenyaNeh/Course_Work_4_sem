﻿--insert CPUs values('AMD', 'AMD Ryzen 5 5600G', 'D:\University\Course_Work\artTech\artTech\Resources\Image\cpu1.jpg', 117, 'AM4', 'DDR4', 'Radeon Vega 7 (7 cores, 1900 MHz)', 65)
--delete CPUs where CPU_Manufacturer = 'AMD'
