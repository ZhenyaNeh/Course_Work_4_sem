﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace artTech.Controll
{
    public static class ComparisonModeControl
    {
        public static bool ComparisonModeIsActive {get; set;} = false;
    }
}
